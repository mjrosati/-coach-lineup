Coach Lineup — Line Selector Color Fix

What changed:
- The top line selector now changes background/border color to match the active line.
- Red Line -> red
- Blue Line -> blue
- Green Line -> green
- Gold Line -> gold
- Scout Line -> purple

Upload these updated files to GitHub and replace the existing versions:
1. app.js
2. sw.js

You do NOT need to replace your roster, database, or Supabase setup.
After GitHub Pages redeploys, refresh the site. If the old version is cached, close the web app/browser and reopen it.
