# Coach Lineup — Installable PWA + Shared Team Accounts

This package is the next-stage foundation for the Coach Lineup football app.

## What is included

- Installable PWA for iPhone/iPad/Android/desktop browsers
- Email/password accounts
- Shared team membership
- Team invite code
- Cloud player roster
- Shared line names/colors
- Full-screen field play screen
- Names / numbers toggle
- Editable position labels UI
- Playing-time tracking structure
- Configurable playing-time warning
- Supabase Row Level Security database schema
- Realtime subscription foundation for shared roster/line changes

## Important: this is not yet a public app-store release

I can create the software project here, but a real shared cloud app needs a Supabase project and a web host. The included app is ready for that setup.

### 1. Create the database

Create a Supabase project.

Open the SQL Editor and run `supabase_schema.sql`.

The database uses Auth + Row Level Security so one team's data is separated from another team's data. Supabase recommends protecting exposed tables with RLS and using a publishable key in browser apps; never put a service_role/secret key in the browser.

### 2. Configure the app

Copy:

`config.example.js`

to:

`config.js`

Then put your Supabase project URL and publishable key in it.

Example:

window.SUPABASE_URL = "https://YOURPROJECT.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "YOUR_PUBLISHABLE_KEY";

### 3. Host it over HTTPS

Upload the project to a static host such as GitHub Pages, Netlify, Cloudflare Pages, or Vercel.

A PWA must be served from a secure origin (HTTPS, except localhost during development).

### 4. Install on an iPhone/iPad

Open the hosted HTTPS address in Safari.

Use Share → Add to Home Screen.

The app will launch in standalone/full-screen mode.

### 5. Install on Android

Open the hosted HTTPS address in Chrome.

Use the browser's Install/Add to Home Screen option.

### 6. Share with coaches

Each coach creates their own login, then the team owner creates the team.

The owner shares the generated team invite code.

Coaches join the same team and work from the same cloud roster/line data.

## Recommended next build

The current package is the real PWA foundation, but I would make these the next development steps before using it during a game:

1. Finish exact position-to-player assignment and drag/drop positioning.
2. Save every substitution and field position to the cloud.
3. Make playing-time percentages derive directly from every saved play.
4. Add a live game clock and down/distance.
5. Add a game history screen.
6. Add coach/owner/viewer permissions.
7. Add offline-first game mode so a sideline connection problem does not stop tracking.
8. Add a clean invite screen and QR-code team joining.
9. Add export to CSV/PDF.
10. Package the same code for the Apple App Store and Google Play if you want native store apps.

## Security note

Do not put a Supabase `service_role` key in `config.js` or any browser code. The browser should use the project's publishable key with RLS policies protecting the database.
