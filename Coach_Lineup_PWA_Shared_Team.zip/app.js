const sb=window.supabase.createClient(window.SUPABASE_URL,window.SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:true,autoRefreshToken:true}});
const POS=[
['WRL','WR (Left)',16,18],['WRR','WR (Right)',84,18],['LT','LT',31,29],['LG','LG',41,29],['C','C',50,29],['RG','RG',59,29],['RT','RT',69,29],['QB','QB',50,39],['RBL','RB (Left)',40,46],['RBR','RB (Right)',60,46],['DEL','DE (Left)',26,63],['DTL','DT (Left)',42,63],['DTR','DT (Right)',58,63],['DER','DE (Right)',74,63],['LBL','LB (Left)',29,75],['LBC','LB (Left Center)',44,75],['RBC','LB (Right Center)',58,75],['LBR','LB (Right)',71,75],['CBL','CB (Left)',21,88],['SSL','SS',41,88],['FS','FS',59,88],['CBR','CB (Right)',79,88]
];
let team=null, lines=[], players=[], currentLine=0, display='names', threshold=75, play=0, counts={}, channel=null;

const $=id=>document.getElementById(id);
function msg(t){$('authMsg').textContent=t}
function openModal(html){$('modalBody').innerHTML=html;$('modal').classList.remove('hidden')}
function closeModal(){$('modal').classList.add('hidden')}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

async function boot(){
 const {data:{session}}=await sb.auth.getSession();
 if(session) await loadApp(); else showAuth();
 sb.auth.onAuthStateChange(async(_e,s)=>{if(s) await loadApp(); else showAuth()});
 if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
function showAuth(){$('auth').classList.remove('hidden');$('app').classList.add('hidden')}
async function loadApp(){
 $('auth').classList.add('hidden');$('app').classList.remove('hidden');
 await chooseTeam();
}
async function chooseTeam(){
 const {data,error}=await sb.from('team_members').select('team_id,role,teams(id,name,join_code,owner_id)').order('created_at',{ascending:true});
 if(error){alert(error.message);return}
 if(!data?.length){openTeamModal();return}
 team=data[0].teams; $('teamName').textContent=team.name;$('teamRole').textContent=data[0].role;
 await loadTeam(); subscribe();
}
async function loadTeam(){
 const [p,l]=await Promise.all([
  sb.from('players').select('*').eq('team_id',team.id).order('jersey_number'),
  sb.from('lines').select('*').eq('team_id',team.id).order('sort_order')
 ]);
 players=p.data||[]; lines=l.data||[];
 if(!lines.length){
  for(let i=0;i<5;i++){const ins=await sb.from('lines').insert({team_id:team.id,name:['RED LINE','BLUE LINE','GREEN LINE','GOLD LINE','SCOUT LINE'][i],color:['red','blue','green','gold','purple'][i],sort_order:i}).select().single(); if(ins.data)lines.push(ins.data)}
 }
 renderAll();
}
function subscribe(){
 if(channel) sb.removeChannel(channel);
 channel=sb.channel('team-'+team.id).on('postgres_changes',{event:'*',schema:'public',table:'players',filter:`team_id=eq.${team.id}`},loadTeam).on('postgres_changes',{event:'*',schema:'public',table:'lines',filter:`team_id=eq.${team.id}`},loadTeam).subscribe();
}
function renderAll(){renderLineSelect();renderPlayers();renderField();renderSummary()}
function renderLineSelect(){$('lineSelect').innerHTML=lines.map((l,i)=>`<option value="${i}" ${i===currentLine?'selected':''}>${esc(l.name)}</option>`).join('');$('lineChips').innerHTML=lines.map((l,i)=>`<button class="chip lineChip" style="border-color:${l.color==='gold'?'#eab308':l.color==='purple'?'#a855f7':l.color}" onclick="setLine(${i})">${i+1} ${esc(l.name)}</button>`).join('')}
function renderPlayers(){const q=($('search').value||'').toLowerCase();$('players').innerHTML=players.filter(p=>(p.name+' '+p.jersey_number+' '+p.position).toLowerCase().includes(q)).map(p=>`<div class="player"><span class="num">#${esc(p.jersey_number)}</span><span>${esc(p.name)}<br><small class="muted">${esc(p.position)}</small></span><button class="iconBtn" onclick="editPlayer('${p.id}')">✎</button></div>`).join('')}
function renderField(){
 $('field').querySelectorAll('.slot').forEach(x=>x.remove());
 // Use line_players when available; fallback to first players for the first prototype.
 const pool=players.slice(0,11);
 POS.forEach((pos,i)=>{const p=pool[i%Math.max(1,pool.length)];const e=document.createElement('div');e.className='slot '+(i>=10?'def':'');e.style.left=pos[2]+'%';e.style.top=pos[3]+'%';e.innerHTML=`${esc(pos[1])}<small>${p?(display==='names'?esc(p.name):'#'+esc(p.jersey_number)):'Open'}</small>`;e.onclick=()=>substitute();$('field').appendChild(e)})
}
function renderSummary(){const over=Object.values(counts).filter(v=>v>=threshold).length;$('summary').textContent=`PLAY ${play} • ${over?over+' PLAYER(S) OVER LIMIT':'NO PLAYERS OVER LIMIT'}`;$('warning').textContent=over?'⚠️ PLAYING-TIME ALERT':'✓ ALL GOOD'}
function setLine(i){currentLine=i;renderLineSelect();renderField()}
async function nextPlay(){
 play++; const l=lines[currentLine]; if(!l)return;
 const {data:game}=await sb.from('games').select('id').eq('team_id',team.id).order('created_at',{ascending:false}).limit(1).maybeSingle();
 if(game){const ins=await sb.from('game_plays').insert({game_id:game.id,play_number:play,line_id:l.id,created_by:(await sb.auth.getUser()).data.user.id}).select().single(); if(ins.data){for(const p of players.slice(0,11)){counts[p.id]=(counts[p.id]||0)+1;await sb.from('play_players').insert({game_play_id:ins.data.id,player_id:p.id})}}}
 renderSummary();
}
function prevPlay(){if(play>0)play--;renderSummary()}
function substitute(){openModal(`<h2>Substitute</h2><p class="muted">Choose a player. The next version will assign the player to a specific field slot and preserve the substitution history.</p><div>${players.map(p=>`<button class="secondary" style="margin:4px" onclick="closeModal()">#${esc(p.jersey_number)} ${esc(p.name)}</button>`).join('')}</div><div class="modalFoot"><button class="secondary" onclick="closeModal()">Close</button></div>`)}
async function editPlayer(id){const p=players.find(x=>x.id===id);openPlayerModal(p)}
function openPlayerModal(p=null){openModal(`<h2>${p?'Edit':'Add'} Player</h2><div class="formgrid"><label>Jersey number<input id="pmNum" value="${esc(p?.jersey_number||'')}"></label><label>Name<input id="pmName" value="${esc(p?.name||'')}"></label><label>Position<input id="pmPos" value="${esc(p?.position||'')}"></label></div><div class="modalFoot"><button class="secondary" onclick="closeModal()">Cancel</button><button class="primary" onclick="savePlayer('${p?.id||''}')">Save</button></div>`)}
async function savePlayer(id){const obj={team_id:team.id,jersey_number:$('pmNum').value.trim(),name:$('pmName').value.trim(),position:$('pmPos').value.trim()};if(!obj.name||!obj.jersey_number)return;const q=id?sb.from('players').update(obj).eq('id',id):sb.from('players').insert(obj);const {error}=await q;if(error)alert(error.message);closeModal();await loadTeam()}
function openTeamModal(){openModal(`<h2>Set up your team</h2><p class="muted">Create a new team or join an existing team with its invite code.</p><input id="tmName" class="search" placeholder="New team name"><button class="primary full" onclick="createTeam()">Create Team</button><hr><input id="tmCode" class="search" placeholder="8-character team code"><button class="secondary full" onclick="joinTeam()">Join Team</button>`)}
async function createTeam(){const name=$('tmName').value.trim();if(!name)return;const {data,error}=await sb.rpc('create_team',{team_name:name});if(error)alert(error.message);else{closeModal();await chooseTeam()}}
async function joinTeam(){const code=$('tmCode').value.trim();if(!code)return;const {data,error}=await sb.rpc('join_team',{code});if(error)alert(error.message);else{closeModal();await chooseTeam()}}
function openLines(){openModal(`<h2>Manage Lines</h2>${lines.map(l=>`<div class="formgrid" style="margin-bottom:8px"><label>Line name<input id="ln-${l.id}" value="${esc(l.name)}"></label><label>Color<select id="lc-${l.id}"><option>red</option><option>blue</option><option>green</option><option>gold</option><option>purple</option></select></label></div>`).join('')}<div class="modalFoot"><button class="secondary" onclick="closeModal()">Cancel</button><button class="primary" onclick="saveLines()">Save</button></div>`);lines.forEach(l=>{const s=$('lc-'+l.id);if(s)s.value=l.color})}
async function saveLines(){for(const l of lines)await sb.from('lines').update({name:$('ln-'+l.id).value,color:$('lc-'+l.id).value}).eq('id',l.id);closeModal();await loadTeam()}
function openPositions(){openModal(`<h2>Edit Position Labels</h2><p class="muted">This is saved per team in the production database. These defaults are shown here so you can define your own labels.</p><div class="formgrid">${POS.map((p,i)=>`<label>${p[0]}<input id="pos-${i}" value="${esc(p[1])}"></label>`).join('')}</div><div class="modalFoot"><button class="secondary" onclick="closeModal()">Cancel</button><button class="primary" onclick="closeModal()">Save</button></div>`)}
function openStats(){const rows=players.map(p=>{const c=counts[p.id]||0;const pct=play?Math.round(c/play*100):0;return `<div style="display:flex;gap:10px;padding:8px;border-bottom:1px solid #263241"><span>#${esc(p.jersey_number)}</span><span style="flex:1">${esc(p.name)}</span><span>${c} plays</span><b class="${pct>=threshold?'danger':''}">${pct}%</b></div>`}).join('');openModal(`<h2>Playing Time</h2>${rows}<div class="modalFoot"><button class="secondary" onclick="closeModal()">Close</button></div>`)}
function openGame(){openModal(`<h2>Game</h2><p class="muted">Current play: ${play}. Playing-time warning: ${threshold}%.</p><label>Warning threshold<input id="th" type="number" min="1" max="100" value="${threshold}" class="search"></label><div class="modalFoot"><button class="secondary" onclick="closeModal()">Cancel</button><button class="primary" onclick="threshold=+document.getElementById('th').value;closeModal();renderSummary()">Save</button></div>`)}
$('authBtn').onclick=async()=>{const email=$('email').value,password=$('password').value;const create=$('authBtn').dataset.create==='1';const r=create?await sb.auth.signUp({email,password}):await sb.auth.signInWithPassword({email,password});if(r.error)msg(r.error.message);else msg(create?'Account created. Check your email if confirmation is enabled.':'')}
$('toggleAuth').onclick=()=>{const create=$('authBtn').dataset.create!=='1';$('authBtn').dataset.create=create?'1':'0';$('authBtn').textContent=create?'Create account':'Sign in';$('authTitle').textContent=create?'Create account':'Sign in';$('toggleAuth').textContent=create?'Back to sign in':'Create an account'}
$('addPlayerBtn').onclick=()=>openPlayerModal();$('linesBtn').onclick=openLines;$('positionsBtn').onclick=openPositions;$('subBtn').onclick=substitute;$('statsBtn').onclick=openStats;$('gameBtn').onclick=openGame;$('nextBtn').onclick=nextPlay;$('nextSide').onclick=nextPlay;$('prevBtn').onclick=prevPlay;$('search').oninput=renderPlayers;$('lineSelect').onchange=e=>setLine(+e.target.value);$('namesBtn').onclick=()=>{display='names';$('namesBtn').classList.add('active');$('numbersBtn').classList.remove('active');renderField()};$('numbersBtn').onclick=()=>{display='numbers';$('numbersBtn').classList.add('active');$('namesBtn').classList.remove('active');renderField()};$('teamBtn').onclick=openTeamModal;$('logoutBtn').onclick=()=>sb.auth.signOut();
boot();